export const site={name:'AI Virtual Try-On'};
