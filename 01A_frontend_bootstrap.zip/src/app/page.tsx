export default function Home(){return <main><h1>AI Virtual Try-On</h1></main>}
